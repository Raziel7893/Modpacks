# OfflineChats base ModPack

just a few mods to make controlls a bit more easy

## changelog

### v1.1.0
updated to v62, removed deprecated

### v1.0.2

moar emotes

### v1.0.0

Initial