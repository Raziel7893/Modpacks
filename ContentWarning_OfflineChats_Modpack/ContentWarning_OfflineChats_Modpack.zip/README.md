# OfflineChats base ModPack

just a few mods to make controlls a bit more easy

## changelog

### v1.0.0

Initial